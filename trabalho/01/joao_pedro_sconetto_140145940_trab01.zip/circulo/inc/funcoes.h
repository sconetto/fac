#ifndef _FUNCOES_H
#define _FUNCOES_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <locale.h>
#include <ctype.h>
#include "circulo.h"
#include "operacoes.h"

coordinates read_point();

void print_radius(circle circle);

void print_area(circle circle);

#endif

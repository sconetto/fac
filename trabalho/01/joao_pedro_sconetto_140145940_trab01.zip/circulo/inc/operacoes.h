#ifndef _OPERACOES_H
#define _OPERACOES_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <locale.h>
#include <ctype.h>
#include "circulo.h"
#include "funcoes.h"
#define MATRIX_SIZE 3

int verify_collinearity(coordinates a, coordinates b, coordinates c);

circle verify_trinomial(double a, double b, double c);

#endif
